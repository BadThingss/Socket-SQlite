//
//  RegisterViewController.swift
//  Test
//
//  Created by 胡城阳 on 2018/12/12.
//  Copyright © 2018 胡城阳. All rights reserved.
//

import UIKit
import SQLite
class RegisterViewController: UIViewController {
    var database:Database!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        database = Database()
        database.tableUserCreate() //建表
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var UserName: UITextField!
    @IBOutlet weak var Password: UITextField!
    
    
    //确认按钮逻辑交互
    @IBAction func sureButton(_ sender: Any) {
        guard self.UserName.text!.count >= 6 || self.Password.text!.count >= 6 else {
            print("账号或者秘密小于6位")
            limitlengthAlertView(sender as AnyObject)
            return
        }
        guard database.verify(name:self.UserName.text!) else {
            print("账号已经存在!")
            existAlertView(sender as AnyObject)
            return
        }
        
        database.tableUserInsertItem(Username: self.UserName.text!, password: self.Password.text!)
        database.readUserItem(name: self.UserName.text!)
        
        self.dismiss(animated: true) { () -> Void in
            print("点击了确认按钮")
            let dataDict = [self.UserName.text!:self.Password.text!]
            print(dataDict)
            NotificationCenter.default.post(name:Notification.Name(rawValue: "RegisterCompletionNotification"),object:nil,userInfo:dataDict)
            
        }
        
    }
    
    //取消按钮
    @IBAction func cancelButton(_ sender: Any) {
        self.dismiss(animated: true, completion: {
            print("点击了取消按钮")
        })
    }

    //账号或者密码低于六位的警告栏
    func limitlengthAlertView(_ sender: AnyObject) {
        
        let alertController: UIAlertController = UIAlertController(title: "错误", message: "账号或者密码必须大于六位", preferredStyle: UIAlertController.Style.alert)
        
        let yesAction = UIAlertAction(title: "确定", style: .default) { (alertAction) -> Void in
            NSLog("Tap Yes Button")
        }
        alertController.addAction(yesAction)
        
        //显示
        self.present(alertController, animated: true, completion: nil)
    }
    
    //账号已经存在的警告栏
    func existAlertView(_ sender: AnyObject) {
        
        let alertController: UIAlertController = UIAlertController(title: "错误", message: "账号已经存在", preferredStyle: UIAlertController.Style.alert)
        
        let yesAction = UIAlertAction(title: "确定", style: .default) { (alertAction) -> Void in
            NSLog("Tap Yes Button")
        }
        alertController.addAction(yesAction)
        
        //显示
        self.present(alertController, animated: true, completion: nil)
    }

}
