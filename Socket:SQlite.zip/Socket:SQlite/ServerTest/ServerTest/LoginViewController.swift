//
//  LoginViewController.swift
//  Test
//
//  Created by 胡城阳 on 2018/12/12.
//  Copyright © 2018 胡城阳. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    var database: Database!
    
    @IBOutlet weak var UserName: UITextField! //账号文本框输入
    @IBOutlet weak var PassWord: UITextField! //密码文本框输入
    override func viewDidLoad() {
        super.viewDidLoad()
        database = Database()
    }
    
    
    // 登陆按钮逻辑交互
    @IBAction func SignIN(_ sender: Any) {
        guard self.UserName.text!.count >= 6 || self.PassWord.text!.count >= 6 else {
            print("账号或者秘密小于6位")
            limitlengthAlertView(sender as AnyObject)
            return
        }
        var Str:[String] = []
        Str = database.Compare(name: self.UserName.text!, password: self.PassWord.text!)
        if Str[0] == self.UserName.text! && Str[1] == self.PassWord.text!{
            self.present(Socketview(),animated: true,completion: nil)
            print("UserName:\(self.UserName.text!),PassWord:\(self.PassWord.text!)")
        }else{
            print("账号密码错误")
            matchingAlertView(sender as AnyObject)
        }

}
    //账号或者秘密低于六位的警告栏
    func limitlengthAlertView(_ sender: AnyObject) {
        
        let alertController: UIAlertController = UIAlertController(title: "错误", message: "账号或者密码必须大于六位", preferredStyle: UIAlertController.Style.alert)
        
        let yesAction = UIAlertAction(title: "确定", style: .default) { (alertAction) -> Void in
            NSLog("Tap Yes Button")
        }
        alertController.addAction(yesAction)
        
        //显示
        self.present(alertController, animated: true, completion: nil)
    }
    
    //账号或者密码不存在的警告栏
    func matchingAlertView(_ sender: AnyObject) {
        
        let alertController: UIAlertController = UIAlertController(title: "错误", message: "账号或者密码不存在或者错误", preferredStyle: UIAlertController.Style.alert)
        
        let yesAction = UIAlertAction(title: "确定", style: .default) { (alertAction) -> Void in
            NSLog("Tap Yes Button")
        }
        alertController.addAction(yesAction)
        
        //显示
        self.present(alertController, animated: true, completion: nil)
    }
    
}

