//
//  Constants.swift
//  Test
//
//  Created by 胡城阳 on 2018/12/11.
//  Copyright © 2018 胡城阳. All rights reserved.
//

import UIKit

// color
let MW_WHITE_COLOR          = UIColor.white // white color #ffffff
let MW_BLACK_COLOR          = UIColor.black // black color #000000

// 字符串
let MW_RANGE_LOCATION       = "rangeLocation"           // range 位置
let MW_RANGE_LENGTH         = "rangeLength"             // range 长度
