//
//  DataBase.swift
//  Test
//
//  Created by 胡城阳 on 2018/12/12.
//  Copyright © 2018 胡城阳. All rights reserved.
//

import Foundation
import SQLite

struct Database {
    
    var db: Connection!
    
    init() {
        connectDatabase()
    }
    
    // 建立到数据库的连接
    mutating func connectDatabase(filePath: String = "/Documents") -> Void {
        
        let sqlFilePath = NSHomeDirectory() + filePath + "/databaseserver.sqlite3"
        
        do {
            db = try Connection(sqlFilePath)
            print("与数据库建立连接 成功")
        } catch {
            print("与数据库建立连接 失败：\(error)")
        }
       }
        let Table_sign = Table("table_sign")
        let User_ID = Expression<Int64>("uesr_ID")
        let User_Name = Expression<String>("user_Name")
        let User_Password = Expression<String>("user_Password")
        
    //建表
        func tableUserCreate() -> Void {
            do { //  Create a table TABLE_sign
                try db.run(Table_sign.create { table in
                    table.column(User_ID, primaryKey: .autoincrement) // 主键自加且不为空
                    table.column(User_Name)
                    table.column(User_Password)
                })
                print("创建表 TABLE_SIGN 成功")
            } catch {
                print("创建表 TABLE_SGIN 失败：\(error)")
            }
        }
    //插入数据
        func tableUserInsertItem(Username: String, password: String) -> Void {
            let insert = Table_sign.insert(User_Name <- Username, User_Password <- password)
            do {
                let rowid = try db.run(insert)
                print("插入数据成功 id: \(rowid)")
            } catch {
                print("插入数据失败: \(error)")
            }
        }
    //打印数据
        func readUserItem(name: String) -> Void {
            for item in try! db.prepare(Table_sign.filter(User_Name == name)) {
                print("\n读取（用户名）id: \(item[User_ID]), username: \(item[User_Name]), password: \(item[User_Password])")
            }
            
        }
    //删除数据
        func tableUserDeleteItem(name: String) -> Void {
            let item = Table_sign.filter(User_Name == name)
            do {
                if try db.run(item.delete()) > 0 {
                    print("用户\(User_Name) 删除成功")
                } else {
                    print("没有发现 用户名 \(User_Name)")
                }
            } catch {
                print("灯光\(User_Name) 删除失败：\(error)")
            }
        }
    //遍历数据库
        func queryUserLamp() -> Void {
            for item in (try! db.prepare(Table_sign)) {
                print("用户名 遍历 ———— id: \(item[User_ID]), name: \(item[User_Name]), password: \(item[User_Password])")
            }
    }
    
    //匹配数据库，匹配成功返回账号密码
       func Compare(name:String,password:String) -> [String]{
        for item in (try! db.prepare(Table_sign)) {
            if name == item[User_Name] && password == item[User_Password]{
                return [item[User_Name],item[User_Password]]
            }
        }
        return ["1","1"]
    }
    //判断账号是否已经存在
    func verify(name:String) -> Bool {
        for item in (try! db.prepare(Table_sign)) {
            if name == item[User_Name]{
                return false
            }
        }
        return true
    }

}

