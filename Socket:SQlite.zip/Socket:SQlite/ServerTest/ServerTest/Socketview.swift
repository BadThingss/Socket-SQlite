//
//  ViewControllertwo.swift
//  Test
//
//  Created by 胡城阳 on 2018/12/11.
//  Copyright © 2018 胡城阳. All rights reserved.
//


import UIKit
import CocoaAsyncSocket

class Socketview: UIViewController {
    
    var portField: UITextField!         // 端口号
    var messageField: UITextField!      // 信息输入框
    var logView: UITextView!            // 日中
    var serverSocket: GCDAsyncSocket!   // 服务器 socket
    var clientSocket: GCDAsyncSocket!   // 客服端 socket
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white //设置背景颜色
        addViews()
        serverSocket = GCDAsyncSocket(delegate: self, delegateQueue: DispatchQueue.main) //设置代理
    }
}

extension Socketview {
    
    func addViews() {
        
        // 定义端口UI
        let portLabel = UILabel(title: "端口", fontSize: 15, color: MW_BLACK_COLOR)
        portLabel.frame = CGRect(x: 50, y: 80, width: 35, height: 15)
        portField = UITextField(placeholder: "请输入端口号", placeholderColor: UIColor.lightGray, placeholderFontSize: 13, textColor: MW_BLACK_COLOR, textFontSize: 13)
        
        portField.frame = CGRect(x: 90, y: 80, width: 150, height: 20)
        portField.keyboardType = .numberPad
        portField.layer.borderWidth = 1
        portField.layer.borderColor = UIColor.lightGray.cgColor
        portField.layer.cornerRadius = 4
        // 定义返回按钮
        let backMain = UIButton(title: "返回", fontSize: 14, titleColor: UIColor.blue)
        backMain.addTarget(self, action: #selector(backMainView(button:)), for: .touchUpInside)
        backMain.frame = CGRect(x: 30, y: 40, width: 50, height: 30)
        backMain.setTitle("返回", for: .selected)
        // 开始监听
        let startListen = UIButton(title: "开始监听", fontSize: 14, titleColor: UIColor.blue)
        startListen.setTitle("停止监听", for: .selected)
        
        startListen.addTarget(self, action: #selector(clickListen(button:)), for: .touchUpInside)
        
        startListen.frame = CGRect(x: 270, y: 80, width: 90, height: 20)
        startListen.layer.borderWidth = 1
        startListen.layer.borderColor = UIColor.blue.cgColor
        startListen.layer.cornerRadius = 4
        // 信息输入提示栏
        messageField = UITextField(placeholder: "请输入信息", placeholderColor: UIColor.lightGray, placeholderFontSize: 13, textColor: MW_BLACK_COLOR, textFontSize: 13)
        
        messageField.frame = CGRect(x: 90, y: 180, width: 150, height: 20)
        messageField.layer.borderWidth = 1
        messageField.layer.borderColor = UIColor.lightGray.cgColor
        messageField.layer.cornerRadius = 4
        // 发送信息
        let sendMsgBtn = UIButton(title: "发送信息", fontSize: 14, titleColor: UIColor.blue)
        
        sendMsgBtn.addTarget(self, action: #selector(sendMessage), for: .touchUpInside)
        
        sendMsgBtn.frame = CGRect(x: 270, y: 180, width: 90, height: 20)
        sendMsgBtn.layer.borderWidth = 1
        sendMsgBtn.layer.borderColor = UIColor.blue.cgColor
        sendMsgBtn.layer.cornerRadius = 4
        // 显示信息
        logView = UITextView(textColor: UIColor.gray, textFontSize: 15)
        logView.backgroundColor = UIColor.yellow
        logView.frame = CGRect(x: 50, y: 280, width: MW_SCREEN_WIDTH() - 100, height: 300)
        
        view.addSubview(backMain)
        view.addSubview(portLabel)
        view.addSubview(portField)
        view.addSubview(startListen)
        view.addSubview(messageField)
        view.addSubview(sendMsgBtn)
        view.addSubview(logView)
    }
}

extension Socketview {
    @objc func backMainView(button:UIButton) {
        
    self.dismiss(animated: true, completion: nil)
    }
    // 发送信息
    @objc func sendMessage() {
        
        view.endEditing(true)
        
        let data = messageField.text?.data(using: .utf8)
        
        clientSocket.write(data!, withTimeout: -1, tag: 0)
    }
    // 点击监视器
    @objc func clickListen(button: UIButton) {
        
        button.isSelected = !button.isSelected
        
        button.isSelected ? startReceive() : stopListen()
    }
    
    // 停止监听
    func stopListen() {
        
        serverSocket.disconnect()
        showMessage("Stop listen")
    }
    // 开始监听
    func startReceive() {
        
        view.endEditing(true)
        
        let ports = portField.text ?? ""
        guard let port = UInt16(ports) else {
            
            showMessage("The port number have some questions")
            return
        }
        
        do {
            try serverSocket.accept(onPort: port)
            showMessage("Listening...")
        } catch {
            showMessage("Boot failure")
        }
    }
    // 套接字是客户机的套接字，指示从哪个客户机读取消息
    func receiveMessage() {
        
        view.endEditing(true)
        
        clientSocket.readData(withTimeout: 11, tag: 0)
    }
    // 显示消息
    func showMessage(_ str: String) {
        
        logView.text = logView.text.appendingFormat("%@\n", str)
    }
}

extension Socketview: GCDAsyncSocketDelegate {
    // 停止连接
    func socketDidDisconnect(_ sock: GCDAsyncSocket, withError err: Error?) {
        
        showMessage("Server side - disconnected")
        clientSocket.disconnect()
    }
    // 连接成功
    func socket(_ sock: GCDAsyncSocket, didAcceptNewSocket newSocket: GCDAsyncSocket) {
        
        // 保存客户端套接字
        clientSocket = newSocket
        
        showMessage("Connect success")
        
        let address = "Server：" + "\(newSocket.connectedHost ?? " ")" + " -Port：" + "\(newSocket.connectedPort)"
        
        showMessage(address)
        
        clientSocket.readData(withTimeout: -1, tag: 0)
    }
    // 接受信息
    func socket(_ sock: GCDAsyncSocket, didRead data: Data, withTag tag: Int) {
        
        let text = String(data: data, encoding: .utf8)
        
        showMessage(text!)
        
        clientSocket.readData(withTimeout: -1, tag: 0)
    }
}
