//
//  RegisterViewController.swift
//  Test
//
//  Created by 胡城阳 on 2018/12/12.
//  Copyright © 2018 胡城阳. All rights reserved.
//

import UIKit
import SQLite

//注册页面代码
class RegisterViewController: UIViewController {
        var database: Database!

    override func viewDidLoad() {
        super.viewDidLoad()
        database = Database()
        database.tableUserCreate()//建表
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var UserName: UITextField! //账号输入框
    @IBOutlet weak var Password: UITextField! //密码输入框
    
    //注册的确认按钮
    @IBAction func sureButton(_ sender: Any) {
        // 要求用户注册的账号密码必须大于六位数
        guard self.UserName.text!.count >= 6 || self.Password.text!.count >= 6 else {
            print("账号或者秘密小于6位")
            limitlengthAlertView(sender as AnyObject)
            return
        }
        // 判断用户注册的账号是否已经再数据库里存在
        guard database.verify(name:self.UserName.text!) else {
            print("账号已经存在!")
            existAlertView(sender as AnyObject)
            return
        }
        
        //将用户输入的账号密码导入数据库里面
        database.tableUserInsertItem(Username: self.UserName.text!, password: self.Password.text!)
        //打印用户输入的账号及相关信息
        database.readUserItem(name: self.UserName.text!)
        //点击确认后返回主页面
        self.dismiss(animated: true) { () -> Void in
            print("点击了确认按钮")
        }
        
    }
    //取消按钮
    @IBAction func cancelButton(_ sender: Any) {
        self.dismiss(animated: true, completion: {
            print("点击了取消按钮")
        })
    }
    //警告窗
    func limitlengthAlertView(_ sender: AnyObject) {
        
        let alertController: UIAlertController = UIAlertController(title: "错误", message: "账号或者密码必须大于六位", preferredStyle: UIAlertController.Style.alert)
        
        let yesAction = UIAlertAction(title: "确定", style: .default) { (alertAction) -> Void in
            NSLog("Tap Yes Button")
        }
        alertController.addAction(yesAction)
        
        //显示
        self.present(alertController, animated: true, completion: nil)
    }
    
    func existAlertView(_ sender: AnyObject) {
        
        let alertController: UIAlertController = UIAlertController(title: "错误", message: "账号已经存在", preferredStyle: UIAlertController.Style.alert)
        
        let yesAction = UIAlertAction(title: "确定", style: .default) { (alertAction) -> Void in
            NSLog("Tap Yes Button")
        }
        alertController.addAction(yesAction)
        
        //显示
        self.present(alertController, animated: true, completion: nil)
    }

}
