//
//  LoginViewController.swift
//  Test
//
//  Created by 胡城阳 on 2018/12/12.
//  Copyright © 2018 胡城阳. All rights reserved.
//

import UIKit

//登陆页面代码
class LoginViewController: UIViewController {
    var database: Database!
    
    @IBOutlet weak var UserName: UITextField! //账号显示框
    @IBOutlet weak var PassWord: UITextField! //密码显示框
    override func viewDidLoad() {
        super.viewDidLoad()
        database = Database()
        // Do any additional setup after loading the view.
    }
    
    //登陆按钮
    @IBAction func SignIN(_ sender: Any) {
        // 要求用户输入的账号密码必须大于六位数
        guard self.UserName.text!.count >= 6 || self.PassWord.text!.count >= 6 else {
            print("账号或者秘密小于6位")
            limitlengthAlertView(sender as AnyObject)
            return
        }
        // 判断用户输入的账号密码是否与数据库里面的相匹配，如果账号或者密码错误则弹出 提示框
        var Str:[String] = []
        Str = database.Compare(name: self.UserName.text!, password: self.PassWord.text!)
        if Str[0] == self.UserName.text! && Str[1] == self.PassWord.text!{
            self.present(Socketview(),animated: true,completion: nil)
            print("UserName:\(self.UserName.text!),PassWord:\(self.PassWord.text!)")
        }else{
            print("账号密码错误")
            matchingAlertView(sender as AnyObject)
        }

}
    //警告框
    func limitlengthAlertView(_ sender: AnyObject) {
        
        let alertController: UIAlertController = UIAlertController(title: "错误", message: "账号或者密码必须大于六位", preferredStyle: UIAlertController.Style.alert)
        
        let yesAction = UIAlertAction(title: "确定", style: .default) { (alertAction) -> Void in
            NSLog("Tap Yes Button")
        }
        alertController.addAction(yesAction)
        
        //显示
        self.present(alertController, animated: true, completion: nil)
    }
    
    func matchingAlertView(_ sender: AnyObject) {
        
        let alertController: UIAlertController = UIAlertController(title: "错误", message: "账号或者密码不存在或者错误", preferredStyle: UIAlertController.Style.alert)
        
        let yesAction = UIAlertAction(title: "确定", style: .default) { (alertAction) -> Void in
            NSLog("Tap Yes Button")
        }
        alertController.addAction(yesAction)
        
        //显示
        self.present(alertController, animated: true, completion: nil)
    }

}
